(function($){
$('.special-tooltip').tooltip({selector: "a[data-toggle=tooltip]"});
SyntaxHighlighter.defaults['toolbar'] = false;
SyntaxHighlighter.all();
})(jQuery);